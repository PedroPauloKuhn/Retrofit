package com.retrofit.dominio

class Company {
    var name: String? = null
    var catchPhrase: String? = null
    var bs: String? = null
}