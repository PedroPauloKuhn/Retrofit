package com.retrofit.dominio

class Geo {
    var lat: String? = null
    var lng: String? = null
}
