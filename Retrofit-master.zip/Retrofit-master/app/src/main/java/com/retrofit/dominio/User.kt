package com.retrofit.dominio

class User {
    var id = 0
    var name: String? = null
    var username: String? = null
    var email: String? = null
    var address: Address? = null
    var phone: String? = null
    var website: String? = null
    var company: Company? = null
}